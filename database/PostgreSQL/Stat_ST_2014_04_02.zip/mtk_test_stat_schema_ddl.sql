
CREATE SCHEMA "test_stat";

